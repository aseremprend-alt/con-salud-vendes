
import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  Star, 
  ShieldCheck, 
  Zap, 
  Brain, 
  TrendingUp, 
  Moon, 
  HeartPulse, 
  Clock, 
  Coffee,
  Sparkles,
  ChevronDown,
  ChevronUp,
  ShoppingBag,
  Timer
} from 'lucide-react';

// --- Constants ---

const PRIMARY_PRICE = "96.000 COP";
const TARGET_URL = "https://www.heatlthgreenworld.com/?userNameVARGAS24HGW";

// --- Helper Components ---

const Section = ({ children, className = "", id = "" }: { children?: React.ReactNode, className?: string, id?: string }) => (
  <section id={id} className={`py-16 md:py-24 px-6 md:px-12 ${className}`}>
    <div className="max-w-6xl mx-auto">
      {children}
    </div>
  </section>
);

const Button = ({ children, className = "", onClick }: { children?: React.ReactNode, className?: string, onClick?: () => void }) => (
  <button 
    onClick={onClick}
    className={`px-8 py-4 rounded-full font-bold text-lg transition-all duration-300 transform active:scale-95 shadow-xl ${className}`}
  >
    {children}
  </button>
);

const CTAButton = () => (
  <Button 
    className="bg-blue-600 hover:bg-blue-700 text-white cta-pulse w-full md:w-auto"
    onClick={() => { 
      // Redirect in the same window (prevents opening a new tab)
      window.open(TARGET_URL, "_self");
    }}
  >
    SÍ, QUIERO MI TRANSFORMACIÓN AHORA
  </Button>
);

const FeatureCard = ({ icon: Icon, title, description }: { icon: any, title: string, description: string }) => (
  <div className="bg-white p-8 rounded-2xl shadow-md border border-slate-100 flex flex-col items-center text-center group hover:shadow-xl transition-all">
    <div className="bg-blue-50 p-4 rounded-full mb-6 group-hover:bg-blue-600 transition-colors">
      <Icon className="w-8 h-8 text-blue-600 group-hover:text-white" />
    </div>
    <h3 className="text-xl font-bold mb-4 text-slate-800 uppercase tracking-tight">{title}</h3>
    <p className="text-slate-600 leading-relaxed">{description}</p>
  </div>
);

const StepCard = ({ number, title, description, time }: { number: string, title: string, description: string, time: string }) => (
  <div className="relative flex flex-col md:flex-row gap-8 items-start mb-12 last:mb-0">
    <div className="flex-shrink-0 w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center text-2xl font-black shadow-lg">
      {number}
    </div>
    <div className="flex-grow">
      <div className="flex items-center gap-3 mb-2">
        <h4 className="text-2xl font-black text-slate-900 uppercase">{title}</h4>
        <span className="text-sm font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-full flex items-center gap-1">
          <Clock className="w-4 h-4" /> {time}
        </span>
      </div>
      <p className="text-lg text-slate-600 leading-relaxed">{description}</p>
    </div>
  </div>
);

const TestimonialCard = ({ name, role, stars, quote, age }: { name: string, role: string, stars: number, quote: string, age: number }) => (
  <div className="bg-white p-8 rounded-3xl shadow-lg border border-slate-100 relative overflow-hidden h-full">
    <div className="flex text-yellow-400 mb-4">
      {Array.from({ length: stars }).map((_, i) => (
        <Star key={i} className="w-5 h-5 fill-current" />
      ))}
    </div>
    <p className="text-lg text-slate-700 italic mb-8 relative z-10">"{quote}"</p>
    <div className="mt-auto border-t border-slate-100 pt-6">
      <h5 className="text-xl font-black text-slate-900">— {name}</h5>
      <p className="text-slate-500 font-medium">{role}, {age} años</p>
    </div>
  </div>
);

const FAQItem = ({ question, answer }: { question: string, answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-slate-200 py-6 last:border-0">
      <button 
        className="flex justify-between items-center w-full text-left"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-lg md:text-xl font-bold text-slate-800 pr-4">{question}</span>
        {isOpen ? <ChevronUp className="w-6 h-6 text-blue-600" /> : <ChevronDown className="w-6 h-6 text-blue-600" />}
      </button>
      {isOpen && (
        <div className="mt-4 text-slate-600 leading-relaxed text-lg animate-fadeIn">
          {answer}
        </div>
      )}
    </div>
  );
};

// --- Main Application ---

export default function App() {
  const [timeLeft, setTimeLeft] = useState(3600); // 1 hour urgency

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => (prev > 0 ? prev - 1 : 3600));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen">
      {/* Sticky Urgency Bar */}
      <div className="fixed top-0 left-0 w-full bg-red-600 text-white py-2 z-50 text-center font-bold text-sm tracking-widest flex items-center justify-center gap-2">
        <Timer className="w-4 h-4 animate-pulse" />
        OFERTA POR TIEMPO LIMITADO: TU TRANSFORMACIÓN EXPIRA EN {formatTime(timeLeft)}
      </div>

      {/* Hero Section */}
      <section className="min-h-screen pt-24 pb-12 flex flex-col justify-center bg-slate-950 text-white px-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-20 bg-[url('https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80')] bg-cover bg-center"></div>
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row items-center gap-12 relative z-10">
          <div className="lg:w-3/5 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-blue-600/20 text-blue-400 border border-blue-500/30 px-4 py-2 rounded-full mb-8 font-bold text-sm uppercase tracking-widest">
              <Sparkles className="w-4 h-4" /> Lanzamiento Exclusivo para Emprendedores
            </div>
            <h1 className="text-4xl md:text-6xl xl:text-7xl font-black mb-8 leading-[1.1] tracking-tight">
              ¿Y Si Pudieras <span className="text-blue-500">Manifestar Más Ventas</span>, Energía Ilimitada y Abundancia... Mientras Disfrutas Tu Café Matutino?
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 mb-12 max-w-2xl leading-relaxed font-medium">
              Ganoderma Soluble: Tu ritual diario de éxito y claridad para manifestar abundancia en tu negocio.
            </p>
            <div className="flex flex-col md:flex-row gap-6 justify-center lg:justify-start items-center">
              <CTAButton />
              <p className="text-slate-500 font-bold uppercase tracking-tighter text-sm flex items-center gap-2">
                <ShoppingBag className="w-5 h-5" /> Inversión única: {PRIMARY_PRICE}
              </p>
            </div>
          </div>
          <div className="lg:w-2/5 flex justify-center">
            <img 
              src="https://images.unsplash.com/photo-1550989460-0adf9ea622e2?auto=format&fit=crop&q=80" 
              alt="Ganoderma Coffee Experience" 
              className="rounded-3xl shadow-[0_0_50px_rgba(59,130,246,0.3)] border border-slate-800 transform rotate-2 hover:rotate-0 transition-transform duration-500"
            />
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <Section className="bg-white">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-5xl font-black mb-8 text-slate-900 leading-tight uppercase">
              Déjame adivinar...
            </h2>
            <div className="space-y-6 text-xl text-slate-600 leading-relaxed">
              <p>Te levantas cada mañana con grandes sueños para tu negocio, pero a media tarde ya estás agotado, sin energía y con la mente nublada.</p>
              <p>Has probado todos los trucos de productividad que existen, pero nada parece funcionar de manera sostenible.</p>
              <p>Dependes del café convencional que te da un subidón rápido... seguido de un bajón aún más rápido, dejándote más cansado que antes.</p>
              <p className="font-bold text-slate-900 border-l-4 border-blue-600 pl-6 py-4 bg-slate-50">
                Quieres manifestar abundancia en tu negocio, pero ¿cómo puedes hacerlo cuando tu cuerpo y mente no están alineados con esa energía?
              </p>
              <p>La verdad es esta: No es tu culpa. Nadie te enseñó que tu estado físico y mental son la BASE de tu capacidad para manifestar.</p>
            </div>
          </div>
          <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100 shadow-inner">
             <img src="https://images.unsplash.com/photo-1512133595763-5e7428882b8d?auto=format&fit=crop&q=80" alt="Emprendedor agotado" className="rounded-2xl shadow-xl mb-6" />
             <p className="text-center font-bold text-slate-400 uppercase tracking-widest text-sm italic">"La manifestación comienza desde adentro."</p>
          </div>
        </div>
      </Section>

      {/* Pricing */}
      <Section id="pricing" className="bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-7xl font-black mb-8 text-slate-900 uppercase tracking-tighter">Tu Inversión Hoy</h2>
          <div className="bg-slate-50 border-4 border-blue-600 rounded-[3rem] p-12 shadow-2xl relative">
            <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-8 py-2 rounded-full font-black text-sm uppercase tracking-widest">
              Mejor Oferta Disponible
            </div>
            <p className="text-slate-500 line-through text-2xl mb-2 font-bold">$250,000 COP</p>
            <h3 className="text-6xl md:text-8xl font-black text-blue-600 mb-8">{PRIMARY_PRICE}</h3>
            <div className="space-y-4 mb-12 text-left max-w-md mx-auto">
              {[
                "Ganoderma Soluble Coffee Premium",
                "Certificaciones de calidad HGW",
                "Comunidad privada de emprendedores",
                "Guía de ritual de manifestación (PDF)",
                "Soporte directo ilimitado"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                  <span className="font-bold text-slate-700 uppercase text-sm">{item}</span>
                </div>
              ))}
            </div>
            <CTAButton />
            <p className="mt-8 text-slate-400 font-bold uppercase tracking-tighter text-xs">
              Pago 100% seguro | Envío discreto | Soporte dedicado
            </p>
          </div>
        </div>
      </Section>

      {/* Footer */}
      <footer className="bg-slate-950 text-slate-500 py-12 px-6 text-center text-sm border-t border-slate-900">
        <p className="mb-4">&copy; {new Date().getFullYear()} Ganoderma Soluble Coffee - Todos los derechos reservados.</p>
        <a href={TARGET_URL} target="_self" className="hover:text-blue-500 transition-colors mb-2 block font-bold uppercase tracking-widest text-xs">Visitar Tienda Oficial HGW</a>
        <p className="max-w-2xl mx-auto opacity-50 mt-4">
          Este producto no pretende diagnosticar, tratar, curar o prevenir ninguna enfermedad. Los resultados pueden variar según la persona.
        </p>
      </footer>
    </div>
  );
}
